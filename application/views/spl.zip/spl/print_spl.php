<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Cetak data Peminjaman</title>
    <link href="<?= base_url('assets/'); ?>css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
</head>
<style>
    .line-title {
        border: 0;
        border-style: inset;
        border-top: 3px solid #000;
    }
</style>

<body class="sb-nav-fixed">
    <img src="<?= base_url('assets/') ?>img/logo/gmi.png" style="position:absolute; width:200px; height:auto" alt="">
    <table style="width: 100%;">
        <tr>
            <td align="center">
                <span style="line-height: 1.6; font-weight: bold; font-family: 'Times New Roman', Times, serif">
                    <h1>PENGAJUAN SURAT PERINTAH LEMBUR
                        <br>PT. GARUDA MART INDONESIA</h1>
                </span>
            </td>
        </tr>
    </table>
    <hr class="line-title">
    <form class="user" method="POST" action="">
        <div class="col-sm-12 mb-3 mb-sm-0" align="center">
            <h3 align="center" style="margin-top: 30px;font-family: 'Times New Roman', Times, serif">Data Pengajuan SPL
            </h3>
            <hr>

            <table class="table table-bordered" style="font-family: 'Times New Roman', Times, serif;font-size:smaller;">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Status</th>
                        <th scope="col">Kode SPL</th>
                        <th scope="col">Tanggal Pengajuan</th>
                        <th scope="col">Atas Nama</th>
                        <th scope="col">Devisi</th>
                        <th scope="col">Untuk Tanggal</th>
                        <th scope="col">Sampai Dengan</th>
                        <th scope="col">Jam</th>
                        <th scope="col">Anggota</th>
                        <th scope="col">Pekerjaan</th>
                        <th scope="col">Persetujuan</th>
                        <th scope="col">Catatan</th>
                    </tr>
                </thead>
                <?php $i = 1; ?>
                <?php foreach ($spl as $d) : ?>
                    <tbody>
                        <tr>
                            <th scope=#><?= $i; ?></th>
                            <td><?= $d->status ?></td>
                            <td><?= $d->kode_spl ?></td>
                            <td><?= date('d-M-Y', $d->date_created);   ?></td>
                            <td><?= $d->nama ?></td>
                            <td><?= $d->devisi ?></td>
                            <td><?= date('d-M-Y', strtotime($d->tanggal));   ?></td>
                            <td><?= date('d-M-Y', strtotime($d->date_end)); ?></td>
                            <td><?= $d->jam; ?></td>
                            <td><?= $d->anggota; ?></td>
                            <td><?= $d->pekerjaan; ?></td>
                            <td><?= $d->mengetahui; ?></td>
                            <td><?= $d->note ?></td>
                        </tr>
                    </tbody>
                    <?php $i++ ?>
                <?php endforeach; ?>
                <tbody>

                </tbody>

            </table>
        </div>
    </form>

    <div style="margin-top: 100px; margin-right:60px " align="right">
        <p>
            Bekasi, <?= date('d-F-Y'); ?>
        </p><br><br><br><br>
        <p>Garuda Mart Indonesia</p>
    </div>




    </div>

    <script type="text/javascript">
        window.print();
    </script>
</body>

</html>