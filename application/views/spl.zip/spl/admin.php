<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4"><?= $title; ?></h1>
            <!-- <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol> -->
            <a class="btn btn-success " href="<?= base_url('Spl/print') ?>" style="margin-bottom: 20px;">Print</a>

            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table mr-1"></i>
                    Data Pengajuan SPL
                </div>
                <div class="card-body">
                    <?= $this->session->flashdata('message'); ?>
                    <form class="user" method="POST" action="<?= base_url('peminjaman/daftar_peminjam'); ?>">

                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="font-size:x-small;">

                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Aksi</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Kode SPL</th>
                                        <th scope="col">Tanggal Pengajuan</th>
                                        <th scope="col">Atas Nama</th>
                                        <th scope="col">Devisi</th>
                                        <th scope="col">Untuk Tanggal</th>
                                        <th scope="col">Sampai Dengan</th>
                                        <th scope="col">jam</th>
                                        <th scope="col">Anggota</th>
                                        <th scope="col">Pekerjaan</th>
                                        <th scope="col">Persetujuan</th>
                                        <th scope="col">Catatan</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($spl as $d) : ?>
                                        <tr>
                                            <th scope=#><?= $i; ?></th>
                                            <td>
                                                <a class=" badge badge-success" href="<?= base_url('Spl/edit/') . $d['id']; ?>"><i class="fas fa-fw fa-edit"></i>Edit</a>
                                                <a class="badge badge-danger" href="<?= base_url('Spl/delete/') . $d['id']; ?>" onclick="return confirm('yakin?');"><i class="fas fa-fw fa-trash"></i>Delete</a>
                                                <a class="badge badge-primary" href="<?= base_url('Spl/cetak/') . $d['id']; ?>">Print</a>
                                            </td>
                                            <td><?= $d['status'] ?></td>
                                            <td><?= $d['kode_spl'] ?></td>
                                            <td><?= date('d-M-Y', $d['date_created']);   ?></td>
                                            <td><?= $d['nama'] ?></td>
                                            <td><?= $d['devisi'] ?></td>
                                            <td><?= $d['tanggal'];   ?></td>
                                            <td><?= $d['date_end']; ?></td>
                                            <td><?= $d['jam']; ?></td>
                                            <td><?= $d['anggota']; ?></td>
                                            <td><?= $d['pekerjaan']; ?></td>
                                            <td><?= $d['mengetahui']; ?></td>
                                            <td><?= $d['note'] ?></td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>
                                    </tr>

                                </tbody>

                            </table>



                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>


    <!-- Modal -->
    <div class="modal fade" id="newMenuModal" tabindex="-1" role="dialog" aria-labelledby="newMenuModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newMenuModalLabel">Tambah Peminjaman</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <!-- Nested Row within Card Body -->
                <div class="row">
                    <!--div class="col-lg-5 d-none d-lg-block bg-register-image"></!--div-->
                    <div class="col-lg">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Form Peminjaman</h1>
                                <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>

                            </div>

                            <form class="user" method="POST" action="<?= base_url('Peminjaman'); ?>">
                                <div class="form-group row">
                                    <div class="col-sm-12 mb-3 mb-sm-0">
                                        <label>Nama Peminjam</label>
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap">
                                        <?= form_error('name', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>

                                </div>
                                <div class="form-group row">
                                    <div class=" col-sm-6">
                                        <label>Tanggal Peminjaman</label>
                                        <input type="date" class="tm form-control" id="tanggal" name="tanggal" placeholder="Tanggal">
                                        <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class=" col-sm-6">
                                        <label>Sampai Dengan</label>
                                        <input type="date" class="tm form-control" id="enddate" name="enddate" placeholder="enddate">
                                        <?= form_error('enddate', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Jam Berangkat</label>
                                        <input type="time" class="form-control" id="jam_berangkat" name="jam_berangkat" placeholder="jam_berangkat">
                                        <?= form_error('jam_berangkat', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Estimasi Waktu</label>
                                        <select class="form-control" id="estimasi" name="estimasi" placeholder="estimasi">

                                            <option>1 jam</option>
                                            <option>3 jam</option>
                                            <option>Setengah hari</option>
                                            <option>1 Hari</option>
                                            <option>lainnya</option>
                                        </select>
                                        <?= form_error('estimasi', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Kendaraan yang dipinjam</label>
                                        <select class="form-control" id="kendaraan" name="kendaraan" placeholder="Pilih Kendaraan">

                                            <?php foreach ($kendaraan as $k) : ?>

                                                <option><?= $k['name'] ?></option>
                                            <?php endforeach; ?>


                                            <?= form_error('kendaraan', '<small class="text-danger pl-3">', '</small>') ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Apakah STNK ada?</label></label>
                                        <select class="form-control" id="stnk" name="stnk" placeholder="Pilih Kendaraan">

                                            <option>Ada</option>
                                            <option>Tidak Ada</option>
                                        </select>
                                        <?= form_error('stnk', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <div class="form-group row">

                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Deskripsi</label>
                                        <input type="text" class="form-control" id="nama_pengguna" name="nama_pengguna" placeholder="Driver dan penumpang / barang">
                                        <?= form_error('nama_pengguna', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Email Aktif</label>
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Pastikan email aktif....">
                                        <?= form_error('email', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>

                                </div>


                                <!-- untuk menampilkan pesan errornya |name tujuan yang memunculkan error | small stylenya-->

                                <div class="form-group">
                                    <label>Alamat Tujuan</label></label>
                                    <input type="address" class="form-control" id="alamat" name="alamat" placeholder="Alamat / Tujuan (Vendor - Customer - dll">
                                    <!--value =  untuk tetap memunculkan isian jika ada salah satu yang error-->
                                    <?= form_error('alamat', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                                <hr>
                                <button type="submit" class="btn btn-primary btn-user btn-block">Ajukan</button>
                                <label>Tunggu hingga proses loading selesai dan kembali ke menu awal</label></label>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>