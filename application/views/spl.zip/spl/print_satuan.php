<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Cetak data User</title>
    <link href="<?= base_url('assets/'); ?>css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
</head>
<style>
    .line-title {
        border: 0;
        border-style: inset;
        border-top: 3px solid #000;
    }
</style>

<body class="sb-nav-fixed">
    <img src="<?= base_url('assets/') ?>img/logo/gmi.png" style="position:absolute; width:200px; height:auto" alt="">
    <table style="width: 100%;">
        <tr>
            <td align="center">
                <span style="line-height: 1.6; font-weight: bold; font-family: 'Times New Roman', Times, serif">
                    <h1>PENGAJUAN SURAT PERINTAH LEMBUR
                        <br>PT. GARUDA MART INDONESIA</h1>
                </span>
            </td>
        </tr>
    </table>
    <hr class="line-title">
    <form class="user" method="POST" action="">
        <div class="col-sm-12 mb-3 mb-sm-0" align="center">
            <h3 align="center" style="margin-top: 30px;font-family: 'Times New Roman', Times, serif"><?= $title; ?></h3>
            </h3>
            <table class="table table-bordered" style="font-family: 'Times New Roman', Times, serif" mx>

                <tbody>

                    <?php foreach ($spl as $p) : ?>
                        <tr>
                            <td>Kode SPL</td>
                            <td><?= $p->kode_spl ?></td>
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td><?= $p->nama ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?= $p->email ?></td>
                        </tr>
                        <tr>
                            <td>Pengajuan</td>
                            <td><?= date('d F Y', ($p->date_created)); ?></td>
                        </tr>
                        <tr>
                            <td>Untuk Tanggal</td>
                            <td><?= date('d F Y', strtotime($p->tanggal)); ?></td>
                        </tr>
                        <tr>
                            <td>Sampai Tanggal</td>
                            <td><?= date('d F Y', strtotime($p->date_end)); ?></td>
                        </tr>
                        <tr>
                            <td>Jam</td>
                            <td><?= $p->jam ?></td>
                        </tr>
                        <tr>
                            <td>Anggota</td>
                            <td><?= $p->anggota ?></td>
                        </tr>
                        <tr>
                            <td>Devisi</td>
                            <td><?= $p->devisi ?></td>
                        </tr>
                        <tr>
                            <td>Keterangan</td>
                            <td><?= $p->note ?></td>
                        </tr>

                    <?php endforeach; ?>
                </tbody>


            </table>

        </div>
    </form>

    <div class="container" style="margin-top: 100px;">


        <p style="text-align: right; margin-right:30px">Bekasi, <?= date('d F Y') ?></p>


        <div class="row" style="text-align: center;">
            <div class="col-md-4 ">
                <p></p>
            </div>
            <div class="col-md-4 ">
                <p>
                    Mengetahui
                </p><br><br><br><br>
                <?php foreach ($spl as $s) : ?>
                    <p><?= $s->mengetahui; ?></p>
                <?php endforeach ?>
            </div>
            <div class="col-md-4">
                <p>
                    Menyetujui
                </p><br><br><br><br>
                <p>MU Inggrid-HRD</p>
            </div>
        </div>
    </div>




    </div>

    <script type="text/javascript">
        window.print();
    </script>
</body>

</html>