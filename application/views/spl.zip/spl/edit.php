<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4"><?= $title; ?></h1>
            <!-- <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol> -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table mr-1"></i>
                    Data Pengajuan SPL
                </div>
                <div class="card-body">
                    <?= $this->session->flashdata('message'); ?>
                    <class="user" method="POST" action="<?= base_url('Spl/index'); ?>">

                        <?php foreach ($spl as $d) : ?>
                            <form action="<?= base_url() . 'Spl/update'; ?>" method="post"></form>
                            <?= form_open_multipart('Spl/update'); ?>

                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="hidden" name="id" class="form-control" value="<?= $d->id ?>">
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="hidden" name="kode" class="form-control" value="<?= $d->kode_spl ?>">
                                </div>
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="hidden" name="email" class="form-control" value="<?= $d->email ?>">
                                </div>

                            </div>
                            <div class="form-group row">
                                <div class="col-sm-6 mb-1 mb-sm-0">
                                    <label>Permintaan dari</label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap" value="<?= $d->nama ?>">
                                    <?= form_error('name', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                                <div class="col-sm-6 mb-1 mb-sm-0">
                                    <label>Devisi</label>
                                    <input type="text" class="form-control" id="devisi" name="devisi" placeholder="Nama Lengkap" value="<?= $d->devisi ?>">
                                    <?= form_error('devisi', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class=" col-sm-6  mb-1">
                                    <label>Tanggal</label>
                                    <input type="date" class="form-control" id="tanggal" name="tanggal" placeholder="Tanggal" value="<?= $d->tanggal ?>">
                                    <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                                <div class=" col-sm-6  mb-1">
                                    <label>Sampai Tanggal</label>
                                    <input type="date" class="form-control" id="date_end" name="date_end" value="<?= $d->date_end ?>">
                                    <?= form_error('date_end', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class=" col-sm-6  mb-1">
                                    <label>Jam Mulai</label>
                                    <input type="time" class="form-control" id="jam" name="jam" value="<?= $d->jam ?>"></input>
                                    <?= form_error('jam', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                                <div class=" col-sm-6  mb-1">
                                    <label>Mengetahui</label>
                                    <select type="text" class="form-control" id="mengetahui" name="mengetahui">
                                        <option selected><?= $d->mengetahui ?></option>
                                        <?php foreach ($devisi as $k) : ?>
                                            <option><?= $k['head'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?= form_error('mengetahui', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class=" col-sm-6  mb-1">
                                    <label>Email Head</label>
                                    <input type="text" class="form-control" id="emailhead" name="emailhead" value="<?= $d->emailhead ?>">
                                    <?= form_error('emialhead', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                                <div class=" col-sm-6  mb-1">
                                    <label>Pekerjaan</label>
                                    <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" value="<?= $d->pekerjaan ?>">
                                    <?= form_error('pekerjaan', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class=" col-sm-6  mb-1">
                                    <label>Status</label>
                                    <select type="text" class="form-control" id="status" name="status">

                                        <option>Disetujui</option>
                                        <option>Ditunda</option>

                                    </select>
                                    <?= form_error('mengetahui', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                                <div class=" col-sm-6  mb-1">
                                    <label>Anggota</label>
                                    <input type="text" class="form-control" id="anggota" name="anggota" value="<?= $d->anggota ?>">
                                    </input>
                                    <?= form_error('anggota', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="form-group row">

                                <div class=" col-sm-12  mb-1">
                                    <label>Catatan</label>
                                    <textarea type="text" class="form-control" id="note" name="note" value="<?= $d->note ?>">
                                    </textarea>
                                    <?= form_error('note', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <hr>
                            <button type="submit" class="btn btn-primary btn-user btn-block">Submit</button>
                        <?php endforeach; ?>
                        </form>
                </div>
            </div>
        </div>
    </main>
</div>
</div>