<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4"><?= $title; ?></h1>
            <!-- <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol> -->
            <a class="btn btn-success " style="margin-bottom: 20px;" href="" data-toggle="modal" data-target="#newCutiModal"><i class="fas fa-fw fa-plus-square"></i>Tambah SPL</a>
            <?= $this->session->flashdata('message'); ?>
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table mr-1"></i>
                    Data Peminjaman Kendaraan
                </div>
                <div class="card-body">

                    <form class="user" method="POST" action="<?= base_url('SPL/daftar_spl'); ?>">

                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0" style="font-size:x-small;">

                                <thead>
                                    <tr style="font-size:smaller ;">
                                        <th scope="col">No</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Kode SPL</th>
                                        <th scope="col">Tanggal Pengajuan</th>
                                        <th scope="col">Atas Nama</th>
                                        <th scope="col">Devisi</th>
                                        <th scope="col">Untuk Tanggal</th>
                                        <th scope="col">Sampai Dengan</th>
                                        <th scope="col">Jam</th>
                                        <th scope="col">Anggota</th>
                                        <th scope="col">Pekerjaan</th>
                                        <th scope="col">Mengetahui</th>
                                        <th scope="col">Catatan</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>

                                    <?php foreach ($spl as $d) : ?>

                                        <tr>
                                            <th scope=#><?= $i; ?></th>
                                            <td><?= $d['status'] ?></td>
                                            <td><?= $d['kode_spl'] ?></td>
                                            <td><?= date('d-m-Y', $d['date_created']);   ?></td>
                                            <td><?= $d['nama'] ?></td>
                                            <td><?= $d['devisi'] ?></td>
                                            <td><?= date('d-M-y', strtotime($d['tanggal'])); ?></td>
                                            <td><?= $d['date_end']; ?></td>
                                            <td><?= $d['jam']; ?></td>
                                            <td><?= $d['anggota']; ?></td>
                                            <td><?= $d['pekerjaan']; ?></td>
                                            <td><?= $d['mengetahui']; ?></td>
                                            <td><?= $d['note'] ?></td>
                                        </tr>
                                        <?php $i++; ?>

                                    <?php endforeach; ?>
                                    </tr>

                                </tbody>
                            </table>



                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>


    <!-- Modal -->
    <div class="modal fade" id="newCutiModal" tabindex="-1" role="dialog" aria-labelledby="newCutiModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newCutiModalLabel">Tambah Pengajuan SPL</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <!-- Nested Row within Card Body -->
                <div class="row">
                    <!--div class="col-lg-5 d-none d-lg-block bg-register-image"></!--div-->
                    <div class="col-lg">
                        <div class="p-5">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Form Pengajuan SPL</h1>
                                <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>

                            </div>

                            <form class="user" method="POST" action="<?= base_url('Spl/index'); ?>">


                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="hidden" class="form-control" id="email" name="email" placeholder="Nama Lengkap" value="<?= $user['email']; ?>" readonly>
                                        <?= form_error('email', '<small class="text-danger pl-3">', '</small>') ?>
                                        <input type="hidden" class="form-control" id="devisi" name="devisi" value="<?= $user['devisi']; ?>" readonly>
                                        <input type="hidden" class="form-control" id="email" name="email" value="<?= $user['email']; ?>" readonly>
                                    </div>

                                </div>

                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>kode SPL</label>
                                        <input type="text" class="form-control" id="kode" name="kode" value="<?= $kode ?>" readonly>
                                        <?= form_error('kode', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Nama PIC</label>
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Nama Lengkap" value="<?= $user['name'] ?>">
                                        <?= form_error('name', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Mengetahui</label>
                                        <select class="form-control" id="mengetahui" name="mengetahui" placeholder="Pilih Mengetahui">
                                            <option value="">Pilih Head Devisi</option>
                                            <?php foreach ($devisi as $k) : ?>
                                                <option><?= $k['head'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <?= form_error('mengetahui', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Email Head</label>
                                        <select class="form-control" id="emailhead" name="emailhead" placeholder="Pilih emailhead">
                                            <option value="">Pilih Email Head</option>
                                            <?php foreach ($devisi as $k) : ?>
                                                <option><?= $k['email'] ?></option>
                                            <?php endforeach; ?>

                                        </select>
                                        <?= form_error('emailhead', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class=" col-sm-6  mb-3 mb-sm-0">
                                        <label>Untuk Tanggal</label>
                                        <input type="date" class="form-control" id="tanggal" name="tanggal" placeholder="Tanggal">
                                        <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class=" col-sm-6  mb-3 mb-sm-0">
                                        <label>Sampai Tanggal</label>
                                        <input type="date" class="form-control" id="date_end" name="date_end" placeholder="date_end">
                                        <?= form_error('date_end', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Jam Mulai</label>
                                        <input type="time" class="form-control" id="jam" name="jam" placeholder="Jam Mulai">
                                        <?= form_error('jam', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <label>Anggota</label>
                                        <textarea type="text" class="form-control" aria-label="With textarea" id="anggota" name="anggota" placeholder="isi nama anggota yang ikut"></textarea>
                                        <?= form_error('anggota', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12 mb-3 mb-sm-0">
                                        <label>Pekerjaaan</label>
                                        <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" placeholder="Instalasi, pemasangan dll">
                                        <?= form_error('pekerjaan', '<small class="text-danger pl-3">', '</small>') ?>
                                    </div>
                                </div>
                                <hr>
                                <button type="submit" class="btn btn-primary btn-user btn-block">Ajukan</button>
                                <label style="font-size: smaller;">Tunggu hingga proses loading selesai dan kembali ke menu awal</label></label>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>