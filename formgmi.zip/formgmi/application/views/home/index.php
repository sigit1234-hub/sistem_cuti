    <!-- Left side column. contains the logo and sidebar -->


    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Dashboard
            </h1>

        </section>
        <!-- Main content -->
        <section class="content">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="alert alert-info alert-dismissible">
                    <div class="inner">
                        <p style="font-family: Verdana, Geneva, Tahoma, sans-serif;font-size:20px">
                            <?= $salam . ", " . $user['nama'] ?>
                        </p>
                    </div>
                </div>

                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-aqua">
                        <div class="inner">
                            <h3><?= number_format($peminjam, 0, ",", "."); ?></h3>

                            <p>Peminjaman hari ini</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-android-car"></i>
                        </div>
                        <a href="#" class="small-box-footer">Peminjaman <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h3><?= number_format($cuti, 0, ",", "."); ?> Cuti</h3>

                            <p>Hari cuti</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-calendar"></i>
                        </div>
                        <a href="#" class="small-box-footer">Lihat Cuti <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-yellow">
                        <div class="inner">
                            <h3><?= number_format($izin, 0, ",", "."); ?> Izin</h3>

                            <p>Hari Izin</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-clock"></i>
                        </div>
                        <a href="#" class="small-box-footer">Lihat Izin <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-xs-6">
                    <!-- small box -->
                    <div class="small-box bg-red">
                        <div class="inner">
                            <h3><?= number_format($spl, 0, ",", "."); ?> SPL</h3>

                            <p>Hari SPL</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-android-settings"></i>
                        </div>
                        <a href="#" class="small-box-footer">Lihat SPL <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
            </div>
            <!-- /.row -->
            <!-- Main row -->
            <div class="row">
                <!-- Left col -->
                <section class="col-lg-7 connectedSortable">
                    <!-- member -->
                    <div class="col-md-12">
                        <!-- USERS LIST -->
                        <div class="box box-danger">
                            <div class="box-header with-border">
                                <h3 class="box-title">Members</h3>

                                <div class="box-tools pull-right">
                                    <span class="label label-danger"></span>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body no-padding">
                                <div class="col-md-12">
                                    <div class="nav-tabs-custom">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#finance" data-toggle="tab">Finance</a></li>
                                            <li><a href="#logistic" data-toggle="tab">Logistic</a></li>
                                            <li><a href="#service" data-toggle="tab">Service</a></li>
                                            <li><a href="#warehouse" data-toggle="tab">warehouse</a></li>
                                            <li><a href="#ga" data-toggle="tab">Ganeral Affair</a></li>
                                            <li><a href="#manufaktur" data-toggle="tab">Manufakture & Pabrikasi</a></li>
                                            <li><a href="#marketing" data-toggle="tab">Marketing</a></li>
                                            <li><a href="#lain" data-toggle="tab">Lainnya</a></li>
                                        </ul>
                                        <div class="tab-content" style="margin-bottom: 10px;">

                                            <div class="active tab-pane" id="finance">
                                                <!-- Chat box -->
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($finance as $f) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $f['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $f['nama'] ?></a>
                                                                <span class="users-list-date"><?= $f['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>


                                            <div class="tab-pane" id="logistic">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($logistic as $l) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $l['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $l['nama'] ?></a>
                                                                <span class="users-list-date"><?= $l['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /.tab-pane -->
                                            <div class="tab-pane" id="service">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($service as $s) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $s['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $s['nama'] ?></a>
                                                                <span class="users-list-date"><?= $s['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>


                                            <div class="tab-pane" id="warehouse">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($warehouse as $w) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $w['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $w['nama'] ?></a>
                                                                <span class="users-list-date"><?= $w['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>

                                            <!-- /.tab-pane -->
                                            <div class="tab-pane" id="ga">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($ga as $g) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $g['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $g['nama'] ?></a>
                                                                <span class="users-list-date"><?= $g['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /.tab-pane -->
                                            <!-- /.tab-pane -->
                                            <div class="tab-pane" id="it">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($it as $i) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $i['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $i['nama'] ?></a>
                                                                <span class="users-list-date"><?= $i['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /.tab-pane -->
                                            <!-- /.tab-pane -->
                                            <div class="tab-pane" id="manufaktur">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($manufaktur as $m) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $m['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $m['nama'] ?></a>
                                                                <span class="users-list-date"><?= $m['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /.tab-pane -->
                                            <!-- /.tab-pane -->
                                            <div class="tab-pane" id="marketing">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($marketing as $mr) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $mr['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $mr['nama'] ?></a>
                                                                <span class="users-list-date"><?= $mr['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="tab-pane" id="lain">
                                                <div class="col-md-12">
                                                    <ul class="users-list">
                                                        <?php foreach ($it as $i) : ?>
                                                            <li>
                                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $i['foto'] ?>" alt="User Image">
                                                                <a class="users-list-name" href="#"><?= $i['nama'] ?></a>
                                                                <span class="users-list-date"><?= $i['jabatan'] ?></span>
                                                            </li>
                                                        <?php endforeach ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /.tab-pane -->
                                        </div>
                                        <!-- /.tab-content -->
                                    </div>
                                    <!-- /.nav-tabs-custom -->
                                </div>
                            </div>

                        </div>
                        <!--/.box -->
                    </div>
                </section>
                <!-- /.Left col -->
                <!-- right col (We are only adding the ID to make the widgets sortable)-->
                <section class="col-lg-5 connectedSortable">


                    <div class="col-md-12">
                        <!-- USERS LIST -->
                        <div class="box box-danger">
                            <div class="box-header with-border">
                                <h3 class="box-title">Ulang Tahun hari ini</h3>

                                <div class="box-tools pull-right">
                                    <span class="label label-primary"></span>
                                </div>
                            </div>
                            <!-- /.box-header -->
                            <div class="box-body no-padding">
                                <div class="col-md-12">
                                    <ul class="users-list">
                                        <?php foreach ($ulangtahun as $w) : ?>
                                            <li>
                                                <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $w['foto'] ?>" alt="User Image">
                                                <a class="users-list-name" href="#"><?= $w['nama'] ?></a>
                                                <span class="users-list-date"><?php if ($w['divisi'] == 1) {
                                                                                    echo "FINANCE";
                                                                                } elseif ($w['divisi'] == 2) {
                                                                                    echo "LOGISTIC";
                                                                                } elseif ($w['divisi'] == 13) {
                                                                                    echo "SERVICE";
                                                                                } elseif ($w['divisi'] == 14) {
                                                                                    echo "WAREHOUSE";
                                                                                } elseif ($w['divisi'] == 15) {
                                                                                    echo "GENERAL AFFAIR";
                                                                                } elseif ($w['divisi'] == 17) {
                                                                                    echo "IT";
                                                                                } elseif ($w['divisi'] == 18) {
                                                                                    echo "MANUFAKTURE & PABRICATION";
                                                                                } elseif ($w['divisi'] == 22) {
                                                                                    echo "MARKETING";
                                                                                } else {
                                                                                    echo "HRD";
                                                                                }
                                                                                ?> / <?= $w['jabatan'] ?></span>
                                            </li>
                                        <?php endforeach ?>
                                    </ul>
                                </div>
                                <!-- /.users-list -->
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer text-center">
                            </div>
                            <!-- /.box-footer -->
                        </div>
                        <!--/.box -->
                    </div>
                </section>
                <!-- right col -->
            </div>
            <!-- /.row (main row) -->

        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->