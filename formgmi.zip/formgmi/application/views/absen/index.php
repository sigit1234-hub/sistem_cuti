<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <h1>
            <?= $title; ?>
        </h1>
        <a class="btn btn-info pull-right" style="margin-bottom: 20px;" href="" data-toggle="modal" data-target="#newIzinModal">
            <i class="fa fa-user-plus"></i><span> Tambah</span>
        </a>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <?= $this->session->flashdata('message'); ?>

                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col" width="1%">No</th>
                                        <th scope="col">Tanggal</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Divisi</th>
                                        <th scope="col">Keterangan</th>
                                        <th scope="col" width="15%">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($data as $d) : ?>
                                        <tr>
                                            <th scope=#><?= $i; ?></th>
                                            <td><?= date('d M Y', strtotime($d['tanggal'])) ?></td>
                                            <td><?php foreach ($karyawan as $kar)
                                                    if ($kar['id'] == $d['nama']) {
                                                        echo $kar['nama'];
                                                    }
                                                ?></td>
                                            <td><?php if ($d['divisi'] == 1) {
                                                    echo "FINANCE";
                                                } elseif ($d['divisi'] == 2) {
                                                    echo "LOGISTIC";
                                                } elseif ($d['divisi'] == 13) {
                                                    echo "SERVICE";
                                                } elseif ($d['divisi'] == 14) {
                                                    echo "WAREHOUSE";
                                                } elseif ($d['divisi'] == 15) {
                                                    echo "GENERAL AFFAIR";
                                                } elseif ($d['divisi'] == 17) {
                                                    echo "IT";
                                                } elseif ($d['divisi'] == 18) {
                                                    echo "MANUFAKTURE & PABRICATION";
                                                } elseif ($d['divisi'] == 22) {
                                                    echo "MARKETING";
                                                } else {
                                                    echo "HRD";
                                                }
                                                ?>
                                            </td>
                                            <td><?= $d['keterangan']; ?></td>
                                            <td>
                                                <button class="btn btn-default" data-toggle="modal" data-target="#editModal<?php echo $d['id']; ?>"><i class=" fa fa-pencil-square"></i></button>
                                                <a href=" <?= base_url('Hrd/delete_absen/') . $d['id']; ?>" class="btn btn-default" onclick="return confirm('yakin?')"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.box-body -->
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="newIzinModal" tabindex="-1" role="dialog" aria-labelledby="newIzinModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="newIzinModalLabel">Tambah Absensi</h4>
            </div>

            <!-- Nested Row within Card Body -->
            <div class="modal-body">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Form</h1>
                    <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>
                </div>
                <form class="user" method="post" action="<?= base_url('Hrd/tambah_absen'); ?>">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="hidden" class="form-control" id="date_created" name="date_created" value="<?= date('d-M-Y H:i:s'); ?>">
                                <select class="form-control select2" id="nama_absen" name="nama_absen" style="width: 100%;">
                                    <option value="#">Pilih Nama</option>
                                    <?php foreach ($karyawan as $i) : ?>
                                        <option value="<?= $i['id'] ?>"><?= $i['nama'] ?></option>
                                    <?php endforeach ?>
                                </select>
                                <?= form_error('nama_absen', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Divisi</label>
                                <select class="form-control select2" id="divisi_user" name="divisi_user" style="width: 100%;">
                                    <option value=""></option>
                                </select>
                                <?= form_error('divisi_user', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Tanggal</label>
                                <input type="text" class="form-control datepicker" id="tanggal" name="tanggal">
                                <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Keterangan</label>
                                <textarea type="text" class="form-control" id="keterangan" name="keterangan"></textarea>
                                <?= form_error('keterangan', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $no = 0;
foreach ($data as $d) : $no++ ?>
    <!-- Modal -->
    <div class="modal fade" id="editModal<?= $d['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Edit<?= $d['id'] ?></h4>
                </div>
                <div class="modal-body">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Form</h1>
                        <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>
                    </div>
                    <form class="user" method="post" action="<?= base_url('Hrd/edit_absen'); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama</label>
                                    <input type="hidden" id="id" name="id" value="<?= $d['id'] ?>">
                                    <select class="form-control select2" id="nama_absen" name="nama_absen" style="width: 100%;">
                                        <option selected value="<?= $d['id'] ?>"><?php foreach ($karyawan as $kar)
                                                                                        if ($kar['id'] == $d['nama']) {
                                                                                            echo $kar['id'];
                                                                                        } ?></option>

                                        <?php foreach ($karyawan as $i) : ?>
                                            <option value="<?= $i['id'] ?>"><?= $i['nama'] ?></option>
                                        <?php endforeach ?>
                                    </select>
                                    <?= form_error('nama_absen', '<small class="text-danger pl-3">', '</small>'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Divisi</label>
                                    <select class="form-control select2" id="divisi_user" name="divisi_user" style="width: 100%;">
                                        <option><?= $d['divisi'] ?></option>
                                    </select>
                                    <?= form_error('divisi', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tanggal</label>
                                    <input type="text" class="form-control datepicker" id="tanggal" name="tanggal" value="<?= $d['tanggal'] ?>">
                                    <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <textarea type="text" class="form-control" id="keterangan" name="keterangan"><?= $d['keterangan'] ?></textarea>
                                    <?= form_error('keterangan', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="reset" class="btn btn-secondary" data-dismiss="modal">Reset</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>