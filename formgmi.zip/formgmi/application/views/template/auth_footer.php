<!--===============================================================================================-->
<script src="<?= base_url('assets/vendor/') ?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/vendor/') ?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/vendor/') ?>vendor/bootstrap/js/popper.js"></script>
<script src="<?= base_url('assets/vendor/') ?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/vendor/') ?>vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/vendor/') ?>vendor/daterangepicker/moment.min.js"></script>
<script src="<?= base_url('assets/vendor/') ?>vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/vendor/') ?>vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/') ?>js/main.js"></script>

</body>

</html>