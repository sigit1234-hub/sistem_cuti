<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <h1>
            <?= $title; ?>
        </h1>
        <div class="pad margin no-print">
            <div class="callout callout-info" style="margin-bottom: 0!important;">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-times-circle fa-lg" style="color:red"></i>
                        Menunggu persetujuan / Dibatalkan
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:blue"></i>
                        Disetujui dengan perubahan waktu
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:green"></i>
                        Disetujui
                    </div>
                </div>
            </div>
        </div>
        <a class="btn btn-info pull-right" style="margin-bottom: 20px;" href="" data-toggle="modal" data-target="#newIzinModal">
            <i class="fa fa-user-plus"></i><span> Tambah</span>
        </a>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <?= $this->session->flashdata('message'); ?>

                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col" width="1%">No</th>
                                        <th scope="col">Status</th>
                                        <th scope="col" width="3%">Tanggal Pengajuan</th>
                                        <th scope="col" width="15%">Nama</th>
                                        <th scope="col" class="text-center">Jenis Izin</th>
                                        <th scope="col" width="15%">Untuk Tanggal</th>
                                        <th scope="col">Durasi</th>
                                        <th scope="col" width="35%">Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($izin as $d) : ?>
                                        <tr>
                                            <th scope=#><?= $i; ?></th>
                                            <td class="users-list clearfix" style="width: 5%;">
                                                <img class="direct-chat-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $d['foto'] ?>">
                                                <?php if ($d['status'] == 1) {
                                                    echo "<i class='fa fa-times-circle fa-lg' style='color:red'></i>";
                                                } elseif ($d['status'] == 3) {
                                                    echo "<i class='fa fa-check-square fa-lg' style='color:blue'></i>";
                                                } elseif ($d['status'] == 4) {
                                                    echo "<i class='fa fa-times-circle fa-lg' style='color:yellow'></i>";
                                                } else {
                                                    echo "<i class='fa fa-check-square fa-lg' style='color:green'></i>";
                                                } ?>
                                            </td>
                                            <td class="text-center"><?= date('d M Y', strtotime($d['tanggal'])) ?></td>
                                            <td><?= $d['nama']; ?></td>
                                            <td class="text-center"><?php if ($d['jenis_izin'] == "Sakit") {
                                                                        echo "<span class='label label-primary'>Sakit</span>";
                                                                    }
                                                                    if ($d['jenis_izin'] == "Keperluan Pribadi") {
                                                                        echo "<span class='label label-warning'>Keperluan Pribadi</span>";
                                                                    }
                                                                    if ($d['jenis_izin'] == "Setengah Hari(pagi)") {
                                                                        echo "<span class='label label-success'>Setengah Hari(pagi)</span>";
                                                                    }
                                                                    if ($d['jenis_izin'] == "Setengah Hari(siang)") {
                                                                        echo "<span class='label label-default'>Setengah Hari(siang)</span>";
                                                                    }
                                                                    ?>
                                            </td>
                                            <td><?php if ($d['tanggal'] == $d['date_end']) {
                                                    echo date('d M Y', strtotime($d['tanggal']));
                                                } elseif (date(' M', strtotime($d['tanggal'])) == date(' M', strtotime($d['date_end']))) {
                                                    echo date('d', strtotime($d['tanggal'])) . "-" . date('d M Y', strtotime($d['date_end']));
                                                } else {
                                                    echo date('d M', strtotime($d['tanggal'])) . "-" . date('d M Y', strtotime($d['date_end']));
                                                }
                                                ?>
                                            </td>
                                            <td><?= $d['durasi'] . " Hari" ?></td>
                                            <td><?= $d['Keterangan']; ?></td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Tanggal Pengajuan</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Jenis Izin</th>
                                        <th scope="col">Untuk Tanggal</th>
                                        <th scope="col">Durasi</th>
                                        <th scope="col">Keterangan</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.box-body -->
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="newIzinModal" tabindex="-1" role="dialog" aria-labelledby="newIzinModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="newIzinModalLabel">Tambah Izin</h4>
            </div>

            <!-- Nested Row within Card Body -->
            <div class="modal-body">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Form Izin</h1>
                    <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>
                </div>
                <form class="user" method="POST" action="<?= base_url('User/izin'); ?>">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="hidden" class="form-control" id="foto" name="foto" value="<?= $user['foto']; ?>">
                                <input type="hidden" class="form-control" id="date_created" name="date_created" value="<?= date('d-M-Y H:i:s'); ?>">
                                <input type="hidden" class="form-control" id="nama_id" name="nama_id" value="<?= $user['id']; ?>">
                                <input type="hidden" class="form-control" id="email" name="email" value="<?= $user['email']; ?>">
                                <input type="text" class="form-control" id="nama" name="nama" value="<?= $user['nama']; ?>">
                                <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                            <div class="form-group">
                                <label>Tanggal Izin</label>
                                <input type="text" class="form-control datepicker" id="tanggal" name="tanggal" placeholder="Tanggal mulai izin">
                                <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jenis Izin</label>
                                <select class="form-control" id="Jenis_izin" name="Jenis_izin" placeholder="Jenis Izin">
                                    <?php foreach ($jenis_izin as $i) : ?>
                                        <option><?= $i['nama'] ?></option>
                                    <?php endforeach ?>
                                </select>
                                <?= form_error('Jenis_izin', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                            <div class="form-group">
                                <label>Sampai Tanggal</label>
                                <input type="text" class="form-control datepicker" id="date_end" name="date_end" placeholder="Tanggal akhir izin">
                                <?= form_error('date_end', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Keterangan</label>
                                <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="Demam /  Kegiatan Kampus / Dll">
                                <?= form_error('keterangan', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <hr>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>