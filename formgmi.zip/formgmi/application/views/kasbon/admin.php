<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <h1>
            <?= $title; ?>
        </h1>
        <div class="pad margin no-print">
            <div class="callout callout-info" style="margin-bottom: 0!important;">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-times-circle fa-lg" style="color:red"></i>
                        Menunggu persetujuan / Dibatalkan
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:blue"></i>
                        Disetujui dengan perubahan waktu
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:green"></i>
                        Disetujui
                    </div>
                </div>
            </div>
        </div>
        <a class="btn btn-info pull-right" style="margin-bottom: 20px;" href="" data-toggle="modal" data-target="#newKasbonModal">
            <i class="fa fa-user-plus"></i><span> Tambah</span>
        </a>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <?= $this->session->flashdata('message'); ?>

                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col" width="1%">No</th>
                                        <th scope="col">Status</th>
                                        <th scope="col" width="8%">Pengajuan</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Status Angsuran</th>
                                        <th scope="col">Jumlah Kasbon</th>
                                        <th scope="col">Angsuran /Bulan</th>
                                        <th scope="col">keterangan</th>
                                        <th scope="col">Catatan</th>
                                        <th scope="col">aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($kasbon as $d) : ?>
                                        <tr>
                                            <th scope=#><?= $i; ?></th>
                                            <td class="users-list clearfix" style="width: 5%;">
                                                <img class="direct-chat-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $d['foto'] ?>">
                                                <?php if ($d['status'] == 1) {
                                                    echo "<i class='fa fa-times-circle fa-lg' style='color:red'></i>";
                                                } elseif ($d['status'] == 3) {
                                                    echo "<i class='fa fa-check-square fa-lg' style='color:blue'></i>";
                                                } elseif ($d['status'] == 4) {
                                                    echo "<i class='fa fa-times-circle fa-lg' style='color:yellow'></i>";
                                                } else {
                                                    echo "<i class='fa fa-check-square fa-lg' style='color:green'></i>";
                                                } ?>
                                            </td>
                                            <td class="text-center"><?= date('d M Y', strtotime($d['date_created'])) ?></td>
                                            <td><?= $d['nama']; ?></td>
                                            <td><?= $d['bayar'] ?></td>
                                            <td><?= "Rp " . number_format($d['kasbon'], 2, ",", ".") . " / " . $d['durasi_angsuran'] . "X" ?></td>
                                            <td><?php if ($d['lainnya'] == null) {
                                                    echo "Rp " . number_format($d['jumlah_angsuran'], 2, ",", ".");
                                                } else {
                                                    echo ($d['lainnya']);
                                                }
                                                ?>
                                            </td>
                                            <td><?= $d['keterangan']; ?></td>
                                            <td><?= $d['note']; ?></td>
                                            <td>
                                                <button alt="Input Angsuran" class="btn btn-default" data-toggle="modal" data-target="#lihatModal<?php echo $d['id']; ?>"><i class=" fa fa-eye"></i></button>
                                                <button class="btn btn-default" data-toggle="modal" data-target="#editModal<?php echo $d['id']; ?>"><i class=" fa fa-pencil-square"></i></button>
                                                <a href=" <?= base_url('Hrd/delete_kasbon/') . $d['id']; ?>" class="btn btn-default" onclick="return confirm('yakin?')"><i class="fa fa-trash"></i></a>
                                                <a alt="Input Angsuran" class="btn btn-default" href="<?= base_url('Hrd/input_angsuran/') . $d['id'] ?>"><i class=" fa fa-money"></i></a>
                                            </td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th scope="col" width="1%">No</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Pengajuan</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Status Angsuran</th>
                                        <th scope="col">Jumlah Kasbon</th>
                                        <th scope="col">Angsuran /Bulan</th>
                                        <th scope="col">keterangan</th>
                                        <th scope="col">Catatan</th>
                                        <th scope="col">aksi</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.box-body -->
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="newKasbonModal" tabindex="-1" role="dialog" aria-labelledby="newKasbonModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="newKasbonModalLabel">Tambah Kasbon</h4>
            </div>

            <!-- Nested Row within Card Body -->
            <div class="modal-body">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Form Pengajuan</h1>
                    <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>
                </div>
                <form class="user" method="POST" action="<?= base_url('User/kasbon'); ?>" width="50%">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="hidden" class="form-control" id="foto" name="foto" value="<?= $user['foto']; ?>">
                                <input type="hidden" class="form-control" id="date_created" name="date_created" value="<?= date('d-M-Y H:i:s'); ?>">
                                <input type="hidden" class="form-control" id="nama_id" name="nama_id" value="<?= $user['id']; ?>">
                                <input type="hidden" class="form-control" id="email" name="email" value="<?= $user['email']; ?>">
                                <input type="text" class="form-control" id="nama" name="nama" value="<?= $user['nama']; ?>">
                                <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Durasi Angsuran</label>
                                <select class="form-control" id="durasikasbon" name="durasikasbon" onkeyup="sum();">
                                    <option value="1">1x (satu)</option>
                                    <option value="2">2x (satu)</option>
                                    <option value="3">3x (satu)</option>
                                    <option value="4">4x (satu)</option>
                                    <option value="5">5x (satu)</option>
                                    <option value="6">6x (satu)</option>
                                    <option value="7">7x (satu)</option>
                                    <option value="8">8x (satu)</option>
                                    <option value="9">9x (satu)</option>
                                    <option value="10">10x (satu)</option>
                                    <option value="11">11x (satu)</option>
                                    <option value="12">12x (satu)</option>
                                </select>
                                <?= form_error('durasi', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jumlah Kasbon</label>
                                <input type="text" class="form-control" id="kasbon" name="kasbon" placeholder="Masukkan hanya angka" onkeyup="sum();" required>
                                <?= form_error('kasbon', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jumlah pembayaran perbulan (abaikan jika memilih angsuran sendiri)</label>
                                <input type="text" class="form-control" id="jumlah_bayar" name="jumlah_bayar" readonly>
                                <?= form_error('jumlah_bayar', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jumlah Angsuran lain</label>
                                <input type="text" class="form-control" id="jumlah_bayar_lain" name="jumlah_bayar_lain" placeholder="1jt 2x, 500 ribu 2x">
                                <?= form_error('jumlah_bayar_lain', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Keterangan</label>
                                <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="pembiayaan kuliah, berobat dll">
                                <?= form_error('keterangan', '<small class="text-danger pl-3">', '</small>') ?>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Reset</button>
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $no = 0;
foreach ($kasbon as $d) : $no++ ?>
    <!-- Modal -->
    <div class="modal fade" id="lihatModal<?= $d['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Detail</h4>
                </div>
                <div class="modal-body">
                    <section class="content">
                        <div class="box box-primary">
                            <div class="box-body box-profile ">
                                <div class="row">
                                    <div class="col-md-12" style="margin-bottom: 10px;">
                                        <!-- START LOCK SCREEN ITEM -->
                                        <div class="user-block">
                                            <img class="img-circle img-bordered-sm" src="<?= base_url('assets/img/profile/') . $d['foto'] ?>" alt="user image">
                                            <span class="username">
                                                <a href="#"><?= $d['nama'] ?></a>
                                                <a href="#" class="pull-right btn-box-tool"></a>
                                            </span>
                                            <span class="description">diajukan pada : <?= $d['date_created'] ?></span>
                                        </div>

                                    </div>
                                    <div class="col-md-12 text-left">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <tr>
                                                    <th style="width:25%">Status</th>
                                                    <td>:<?php if ($d['status'] == 1) {
                                                                echo "<span class='label label-primary'>menunggu Persetujuan</span>";
                                                            } elseif ($d['status'] == 2) {
                                                                echo "<span class='label label-success'>Disetujui</span>";
                                                            } elseif ($d['status'] == 3) {
                                                                echo "<span class='label label-warning'>Disetujui (perubahan)</span>";
                                                            } else {
                                                                echo "<span class='label label-danger'>Dibatalkan</span>";
                                                            } ?>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Tgl Pengajuan</th>
                                                    <td>: <?= date('d M Y', strtotime($d['date_created'])) ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Jumlah Kasbon</th>
                                                    <td>: <?= "Rp " . number_format($d['kasbon'], 2, ",", ".") ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Durasi Angsuran</th>
                                                    <td>: <?= $d['durasi_angsuran'] . "X" ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Jumlah Angsuran</th>
                                                    <td>: <?php if ($d['lainnya'] == null) {
                                                                echo "Rp " . number_format($d['jumlah_angsuran'], 2, ",", ".");
                                                            } else {
                                                                echo ($d['lainnya']);
                                                            }
                                                            ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Keterangan</th>
                                                    <td>: <?= $d['keterangan'] ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Note</th>
                                                    <td>: <?= $d['note'] ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </section>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>

<?php $no = 0;
foreach ($kasbon as $kas) : $no++ ?>
    <!-- Modal edit -->
    <div class="modal fade" id="editModal<?php echo $kas['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="editModalLabel">Edit Kasbon</h4>
                </div>

                <!-- Nested Row within Card Body -->
                <div class="modal-body">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Form Pengajuan</h1>
                        <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>
                    </div>
                    <form class="user" method="POST" action="<?= base_url('Hrd/edit_kasbon'); ?>" width="50%">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama</label>
                                    <input type="hidden" class="form-control" id="nama_id" name="nama_id" value="<?= $kas['id']; ?>">
                                    <input type="text" class="form-control" id="nama" name="nama" value="<?= $kas['nama']; ?>">
                                    <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Durasi Angsuran</label>
                                    <select class="form-control" id="durasikasbon" name="durasikasbon">
                                        <option selected value="<?= $kas['durasi_angsuran'] ?>"><?= $kas['durasi_angsuran'] . "X" ?></option>
                                        <option value="1">1x (satu)</option>
                                        <option value="2">2x (satu)</option>
                                        <option value="3">3x (satu)</option>
                                        <option value="4">4x (satu)</option>
                                        <option value="5">5x (satu)</option>
                                        <option value="6">6x (satu)</option>
                                        <option value="7">7x (satu)</option>
                                        <option value="8">8x (satu)</option>
                                        <option value="9">9x (satu)</option>
                                        <option value="10">10x (satu)</option>
                                        <option value="11">11x (satu)</option>
                                        <option value="12">12x (satu)</option>
                                    </select>
                                    <?= form_error('durasi', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Jumlah Kasbon</label>
                                    <input type="text" class="form-control" id="kasbon" name="kasbon" value="<?= $kas['kasbon'] ?>">
                                    <?= form_error('kasbon', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Jumlah pembayaran perbulan</label>
                                    <input type="text" class="form-control" id="lainnya" name="lainnya" value="<?php if ($kas['lainnya'] == null) {
                                                                                                                    echo $kas['jumlah_angsuran'];
                                                                                                                } else {
                                                                                                                    echo ($kas['lainnya']);
                                                                                                                }
                                                                                                                ?>">
                                    <?= form_error('lainnya', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class=" col-md-6">
                                <div class="form-group">
                                    <label>Status</label>
                                    <select type="text" class="form-control" id="status" name="status">
                                        <option selected value="<?= $kas['status'] ?>">
                                            <?php if ($kas['status'] == 1) {
                                                echo "Menunggu";
                                            } elseif ($kas['status'] == 3) {
                                                echo "Disetujui (Perubahan)";
                                            } elseif ($kas['status'] == 4) {
                                                echo "Dibatalkan>";
                                            } else {
                                                echo "Disetujui";
                                            } ?>
                                        </option>
                                        <option value="2">Setujui</option>
                                        <option value="3">Setujui(Perubahan)</option>
                                        <option value="4">Batalkan</option>
                                    </select>
                                    <?= form_error('status', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?= $kas['keterangan'] ?>">
                                    <?= form_error('keterangan', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Catatan</label>
                                    <input type="text" class="form-control" id="note" name="note" placeholder="pembiayaan kuliah, berobat dll">
                                    <?= form_error('note', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>