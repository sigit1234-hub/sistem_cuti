<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <h1>
            <?= $title; ?>
        </h1>
        <div class="pad margin no-print">
            <div class="callout callout-info" style="margin-bottom: 0!important;">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-times-circle fa-lg" style="color:red"></i>
                        Menunggu persetujuan / Dibatalkan
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:blue"></i>
                        Disetujui dengan perubahan waktu
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:green"></i>
                        Disetujui
                    </div>
                </div>
            </div>
        </div>
        <a class="btn btn-info pull-right" style="margin-bottom: 20px;" href="" data-toggle="modal" data-target="#newInputModal">
            <i class="fa fa-user-plus"></i><span> Tambah</span>
        </a>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <?= $this->session->flashdata('message'); ?>

                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col" width="1%">No</th>
                                        <th scope="col">Tanggal input</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Jumlah Angsuran</th>
                                        <th scope="col">Angsuran ke-</th>
                                        <th scope="col">Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach ($input as $d) : ?>
                                        <tr>
                                            <th scope=#><?= $i; ?></th>
                                            <td class="text-center"><?= date('d M Y', strtotime($d['date_created'])) ?></td>
                                            <td><?= $d['nama']; ?></td>
                                            <td class="text-center"><?= $d['jumlah_bayar'] ?></td>
                                            <td><?= $d['angsuran_ke'] + 1; ?></td>
                                            <td><?= $d['note']; ?></td>
                                        </tr>
                                        <?php $i++; ?>
                                    <?php endforeach; ?>
                                </tbody>
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th>Kasbon</th>
                                        <th>Jumlah Angsuran</th>
                                        <th>Sisa Angsuran</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td><?php foreach ($kasbon as $kas) { ?>
                                                <?= number_format($kas['kasbon'], 0, ",", ".") ?>
                                            <?php } ?>
                                        </td>
                                        <td><?= number_format($jml, 0, ",", ".") ?></td>
                                        <td><?php foreach ($kasbon as $kas) { ?>
                                                <?php
                                                if (($kas['kasbon'] - $jml) == 0) {
                                                    echo "Lunas";
                                                } else {
                                                    $sisa = $kas['kasbon'] - $jml;
                                                    echo "Sisa " .  number_format($sisa, 0, ",", ".");
                                                }
                                                ?>
                                            <?php } ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.box-body -->
    </section>
</div>

<?php $no = 0;
foreach ($kasbon as $k) : $no++ ?>
    <!-- Modal -->
    <div class="modal fade" id="newInputModal" tabindex="-1" role="dialog" aria-labelledby="newInputModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="newInputModalLabel">Input Angsuran</h4>
                </div>

                <!-- Nested Row within Card Body -->
                <div class="modal-body">
                    <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Form Input</h1>
                        <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---</h1>
                    </div>
                    <form class="user" method="POST" action="<?= base_url('hrd/add'); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Nama</label>
                                    <input type="hidden" class="form-control" id="id_kasbon" name="id_kasbon" value="<?= $k['id']; ?>">
                                    <input type="hidden" class="form-control" id="date_created" name="date_created" value="<?= date('d-M-Y') ?>">
                                    <input type="text" class="form-control" id="nama" name="nama" value="<?= $k['nama']; ?>">
                                    <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Kasbon</label>
                                    <input type="text" class="form-control" id="kasbon" name="kasbon" value="<?= $k['kasbon'] ?>">
                                    <?= form_error('kasbon', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Jumlah</label>
                                    <input type="number" class="form-control" id="jumlah" name="jumlah">
                                    <?= form_error('jumlah', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <input type="text" class="form-control" id="note" name="note">
                                    <?= form_error('note', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Telah dibayar</label>
                                    <input type="text" class="form-control" id="jml" name="jml" value="<?= $jml; ?>">
                                    <?= form_error('jml', '<small class="text-danger pl-3">', '</small>') ?>
                                </div>
                            </div>
                            <hr>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>