<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

        <h1>
            <?= $title; ?>
        </h1>
        <div class="pad margin no-print">
            <div class="callout callout-info" style="margin-bottom: 0!important;">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-times-circle fa-lg" style="color:red"></i>
                        Menunggu persetujuan / Dibatalkan
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:blue"></i>
                        Disetujui dengan perubahan waktu
                    </div>
                    <div class="col-md-3">
                        <i class="fa fa-check-square fa-lg" style="color:green"></i>
                        Disetujui
                    </div>
                </div>
            </div>
        </div>
        <a class="btn btn-info pull-right" style="margin-bottom: 20px;" href="" data-toggle="modal" data-target="#newIzinModal">
            <i class="fa fa-user-plus"></i><span> Tambah</span>
        </a>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <?= $this->session->flashdata('message'); ?>

                    <div class="box-body">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Form Pengajuan</h1>
                            <h1 class="h6 text-gray-900 mb-4">---Mohon diisi sesuai dengan kebutuhan---<br>
                                ---Mohon isi dahulu durasi angsurannya---
                            </h1>
                        </div>
                        <form class="user" method="POST" action="<?= base_url('User/kasbon'); ?>" width="50%">
                            <div class="row">
                                <div class="col-md-6 col-md-offset-3">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Nama</label>
                                            <input type="hidden" class="form-control" id="foto" name="foto" value="<?= $user['foto']; ?>">
                                            <input type="hidden" class="form-control" id="date_created" name="date_created" value="<?= date('d-M-Y H:i:s'); ?>">
                                            <input type="hidden" class="form-control" id="nama_id" name="nama_id" value="<?= $user['id']; ?>">
                                            <input type="hidden" class="form-control" id="email" name="email" value="<?= $user['email']; ?>">
                                            <input type="text" class="form-control" id="nama" name="nama" value="<?= $user['nama']; ?>">
                                            <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Durasi Angsuran</label>
                                            <select class="form-control" id="durasikasbon" name="durasikasbon" onkeyup="sum();">
                                                <option value="1">1x (satu)</option>
                                                <option value="2">2x (satu)</option>
                                                <option value="3">3x (satu)</option>
                                                <option value="4">4x (satu)</option>
                                                <option value="5">5x (satu)</option>
                                                <option value="6">6x (satu)</option>
                                                <option value="7">7x (satu)</option>
                                                <option value="8">8x (satu)</option>
                                                <option value="9">9x (satu)</option>
                                                <option value="10">10x (satu)</option>
                                                <option value="11">11x (satu)</option>
                                                <option value="12">12x (satu)</option>
                                            </select>
                                            <?= form_error('durasi', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Jumlah Kasbon</label>
                                            <input type="text" class="form-control" id="kasbon" name="kasbon" placeholder="Masukkan hanya angka" onkeyup="sum();" required>
                                            <?= form_error('kasbon', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Jumlah pembayaran perbulan (abaikan jika memilih angsuran sendiri)</label>
                                            <input type="text" class="form-control" id="jumlah_bayar" name="jumlah_bayar" readonly>
                                            <?= form_error('jumlah_bayar', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Jumlah Angsuran lain</label>
                                            <input type="text" class="form-control" id="jumlah_bayar_lain" name="jumlah_bayar_lain" placeholder="1jt 2x, 500 ribu 2x">
                                            <?= form_error('jumlah_bayar_lain', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="pembiayaan kuliah, berobat dll">
                                            <?= form_error('keterangan', '<small class="text-danger pl-3">', '</small>') ?>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-secondary" data-dismiss="modal">Reset</button>
                                        <button type="submit" class="btn btn-primary">Add</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.box-body -->
    </section>
</div>