<div class="limiter">
    <div class="container-login100" style="background-image: url('assets/images/bg-01.jpg');">

        <div class="wrap-login100">
            <form action="<?= base_url('Auth'); ?>" method="post">
                <span class="login100-form-logo">
                    <i><img src="<?= base_url('assets/images/logo_sm.png') ?>" alt=""></i>
                </span>

                <span class="login100-form-title">
                    selamat datang di <br>e-form GMi
                </span>

                <?= $this->session->flashdata('message'); ?>

                <div class="wrap-input100 validate-input" data-validate="Enter username">
                    <input type="text" class="input100" id="email" name="email" placeholder="Username">
                    <span class="focus-input100" data-placeholder="&#xf207;"></span>
                </div>

                <div class="wrap-input100 validate-input" data-validate="Enter password">
                    <input type="password" class="input100" id="password" name="password" placeholder="Password">
                    <span class="focus-input100" data-placeholder="&#xf191;"></span>
                </div>
                <div class="container-login100-form-btn">
                    <button class="login100-form-btn" type="submit">
                        Login
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


<div id="dropDownSelect1"></div>