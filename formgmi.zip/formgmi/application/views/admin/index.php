<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <h1 class="mt-4"><?= $title; ?></h1>
            <!-- <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol> -->
            <a class="btn btn-success " style="margin-bottom: 20px;" href="https://forms.gle/5zj9tGEbr1eHtnud8" data-toggle="modal" data-target="#newCutiModal">Tambah Permintaan</a>

        </div>

</div>
</main>