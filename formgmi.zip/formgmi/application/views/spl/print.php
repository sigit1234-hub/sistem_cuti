<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Print Page</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?= base_url('assets/vendor/admin/') ?>bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url('assets/vendor/admin/') ?>dist/css/AdminLTE.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body onload="window.print();">
    <div class="wrapper">
        <!-- Main content -->
        <section class="invoice">
            <!-- title row -->
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="page-header">
                        <img src="<?= base_url('assets/') ?>images/logo_sm.png" alt=""></i> <?= $title; ?>
                        <small class="pull-right">Tanggal: <?= date('d M Y') ?></small>
                    </h2>
                </div>
                <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                    Data pengaju
                    <address>
                        <?php $i = 1; ?>
                        <?php foreach ($spl as $d) : ?>
                            nama :<strong><?= $d['nama'] ?></strong><br>
                            Divisi : <?php if ($d['divisi'] == 1) {
                                            echo "FINANCE";
                                        } elseif ($d['divisi'] == 2) {
                                            echo "LOGISTIC";
                                        } elseif ($d['divisi'] == 13) {
                                            echo "SERVICE";
                                        } elseif ($d['divisi'] == 14) {
                                            echo "WAREHOUSE";
                                        } elseif ($d['divisi'] == 15) {
                                            echo "GENERAL AFFAIR";
                                        } elseif ($d['divisi'] == 17) {
                                            echo "IT";
                                        } elseif ($d['divisi'] == 22) {
                                            echo "MARKETING";
                                        } else {
                                            echo "MANUFAKTURE & PABRICATION";
                                        } ?><br>
                            Status : <?php if ($d['status'] == 1) {
                                            echo "Menunggu <i class='fa fa-times-circle fa-lg' style='color:red'></i>";
                                        } elseif ($d['status'] == 3) {
                                            echo "Disetujui/perubahan <i class='fa fa-check-square fa-lg' style='color:blue'></i>";
                                        } elseif ($d['status'] == 4) {
                                            echo "Dibatalkan <i class='fa fa-times-circle fa-lg' style='color:yellow'></i>";
                                        } else {
                                            echo "Disetujui <i class='fa fa-check-square fa-lg' style='color:green'></i>";
                                        } ?><br>
                            Tanggal Pengajuan : <?= date('d M Y', strtotime($d['tanggal'])) ?><br>
                            Email : <?= $d['email']; ?><br>

                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-6 invoice-col">
                    <?php $i = 1; ?>
                    <?php foreach ($spl as $d) : ?>
                        <b>Mengetahui: </b><?php foreach ($divisi as $div)
                                                if ($div['email_head'] == $d['emailhead']) {
                                                    echo $div['head'];
                                                }
                                            ?><br>
                        <b>Email:</b> <?= $d['emailhead'] ?><br>
                        <b>Catatan:</b> <?= $d['note'] ?>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </div>
                <!-- /.col -->
                <div class="col-sm-2 invoice-col text-center">

                    <address>
                        <?php $i = 1; ?>
                        <?php foreach ($spl as $d) : ?>
                            <img class="profile-user-img img-responsive img-circle" src="<?= base_url('assets/img/profile/') . $d['foto'] ?>">
                            <?php $i++; ?>
                            <b style="font-style: itali;">#<?= $d['kode_spl'] ?></b>
                        <?php endforeach; ?>

                    </address>
                </div>
            </div>
            <!-- /.row -->

            <!-- Table row -->
            <div class="row">
                <div class="col-xs-12 table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center" width="10%">Tanggal SPL</th>
                                <th class="text-center" width="10%">Estimasi Waktu</th>
                                <th class="text-center">Anggota</th>
                                <th class="text-center">Pekerjaan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php foreach ($spl as $d) : ?>
                                <tr>
                                    <td><?php if ($d['tanggal'] == $d['date_end']) {
                                            echo date('d M Y', strtotime($d['tanggal']));
                                        } elseif (date(' M', strtotime($d['tanggal'])) == date(' M', strtotime($d['date_end']))) {
                                            echo date('d', strtotime($d['tanggal'])) . "-" . date('d M Y', strtotime($d['date_end']));
                                        } else {
                                            echo date('d M', strtotime($d['tanggal'])) . "-" . date('d M Y', strtotime($d['date_end']));
                                        }
                                        ?></td>
                                    <td><?= $d['jam'] . "-" . $d['kembali'] ?></td>
                                    <td><?= $d['anggota'] ?></td>
                                    <td><?= $d['pekerjaan']; ?></td>
                                </tr>
                                <?php $i++; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <div class="row">
                <!-- accepted payments column -->
                <div class="col-xs-4">
                    <p class="lead">Mengetahui:</p>
                    <br><br><br>
                    <p><?php foreach ($divisi as $div)
                            if ($div['email_head'] == $d['emailhead']) {
                                echo $div['head'];
                            }
                        ?></p>
                </div>
                <!-- /.col -->
                <div class="col-xs-4">
                    <p class="lead">Mengetahui:</p>
                    <br><br><br>
                    <p>-------------------</p>
                </div>
                <div class="col-xs-4">
                    <p class="lead">Penerima:</p>
                    <br><br><br>
                    <p><?php foreach ($spl as $d)

                            echo $d['nama'];

                        ?></p>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- ./wrapper -->
    <!-- Code injected by live-server -->
    <script type="text/javascript">
        // <![CDATA[  <-- For SVG support
        if ('WebSocket' in window) {
            (function() {
                function refreshCSS() {
                    var sheets = [].slice.call(document.getElementsByTagName("link"));
                    var head = document.getElementsByTagName("head")[0];
                    for (var i = 0; i < sheets.length; ++i) {
                        var elem = sheets[i];
                        var parent = elem.parentElement || head;
                        parent.removeChild(elem);
                        var rel = elem.rel;
                        if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
                            var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
                            elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
                        }
                        parent.appendChild(elem);
                    }
                }
                var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
                var address = protocol + window.location.host + window.location.pathname + '/ws';
                var socket = new WebSocket(address);
                socket.onmessage = function(msg) {
                    if (msg.data == 'reload') window.location.reload();
                    else if (msg.data == 'refreshcss') refreshCSS();
                };
                if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
                    console.log('Live reload enabled.');
                    sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
                }
            })();
        } else {
            console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
        }
        // ]]>
    </script>
</body>

</html>