<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Ga extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->model('User_m');
        $this->load->model('M_home');
        $this->load->model('M_absen');
        $this->load->model('M_cuti');
        $this->load->model('M_izin');
        $this->load->model('M_kasbon');
        $this->load->model('M_peminjaman');
        $this->load->model('M_spl');
        $this->load->model('Member_model');
        $this->load->model('Menu_model');
    }

    public function admin()
    {
        $data['title'] = "Data Peminjaman";
        $data['user'] = $this->User_m->tampil_data();
        $data['peminjaman'] = $this->M_peminjaman->tampil_data()->result_array();
        $data['get_kendaraan'] = $this->M_peminjaman->kendaraan();
        $data['get_driver'] = $this->M_peminjaman->get_driver();

        $this->load->view('new_template/header', $data);
        $this->load->view('new_template/topbar', $data);
        $this->load->view('new_template/sidebar', $data);
        $this->load->view('ga/admin', $data);
        $this->load->view('new_template/footer');
    }
    public function delete($id)
    {
        $this->M_peminjaman->del($id);

        $this->session->set_flashdata('message', '<div class="alert alert-danger text-center" role="alert">
            Data Telah dihapus!
          </div>');

        redirect('Ga/admin');
    }
    public function edit()
    {
        $post = $this->input->post(null, TRUE);
        $this->M_peminjaman->edit_peminjaman($post);
        $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">
            data berhasil diUpdate!</div>');
        redirect('Ga/admin');
    }
}
