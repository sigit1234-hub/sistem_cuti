<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_cuti extends CI_Model
{
    public function tampil_data($id = null)
    {
        $this->db->from('cuti');
        if ($id != null) {
            $query = $this->db->where('id', $id);
        }
        $query =  $this->db->order_by('id', 'DESC')->get();
        return $query;
    }
    public function cuti_divisi()
    {
        $divisi = $this->session->userdata('divisi');
        return $this->db->order_by('id', 'DESC')->get_where('cuti', ['divisi' => $divisi]);
    }
    public function cuti_head()
    {
        $this->db->where('status1', 2);
        return $this->db->order_by('id', 'DESC')->get('cuti');
    }
    public function getjenis_cuti()
    {
        return $this->db->get('jenis_cuti');
    }
    public function del($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('cuti');
    }

    public function edit_cuti($post)
    {
        $id = $this->input->post('id', true);
        $awal =  htmlspecialchars($this->input->post('tanggal', true));
        $akhir = htmlspecialchars($this->input->post('date_end', true));

        $begin = new DateTime($awal);
        $end = new DateTime($akhir);

        $daterange     = new DatePeriod($begin, new DateInterval('P1D'), $end);
        //mendapatkan range antara dua tanggal dan di looping
        $i = 0;
        $x     =    0;
        $end     =    1;

        foreach ($daterange as $date) {
            $daterange     = $date->format("Y-m-d");
            $datetime     = DateTime::createFromFormat('Y-m-d', $daterange);

            //Convert tanggal untuk mendapatkan nama hari
            $day         = $datetime->format('D');

            //Check untuk menghitung yang bukan hari sabtu dan minggu
            if ($day != "Sun" && $day != "Sat") {
                //echo $i;
                $x    +=    $end - $i;
            }
            $end++;
            $i++;
        }
        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
            'date_end' => htmlspecialchars($this->input->post('date_end', true)),
            'status1' => htmlspecialchars($this->input->post('status', true)),
            'kategori_cuti' => htmlspecialchars($this->input->post('jenis_cuti', true)),
            'mengetahui' => htmlspecialchars($this->input->post('persetujuan', true)),
            'note' => htmlspecialchars($this->input->post('note', true)),
            'durasi' => $x + 1,
            'keterangan' => htmlspecialchars($this->input->post('keterangan', true))
        ];
        $this->db->where('id', $id);
        $this->db->update('cuti', $data);
    }
    public function edit_acc($post)
    {
        $id = $this->input->post('id', true);
        $awal =  htmlspecialchars($this->input->post('tanggal', true));
        $akhir = htmlspecialchars($this->input->post('date_end', true));

        $begin = new DateTime($awal);
        $end = new DateTime($akhir);

        $daterange     = new DatePeriod($begin, new DateInterval('P1D'), $end);
        //mendapatkan range antara dua tanggal dan di looping
        $i = 0;
        $x     =    0;
        $end     =    1;

        foreach ($daterange as $date) {
            $daterange     = $date->format("Y-m-d");
            $datetime     = DateTime::createFromFormat('Y-m-d', $daterange);

            //Convert tanggal untuk mendapatkan nama hari
            $day         = $datetime->format('D');

            //Check untuk menghitung yang bukan hari sabtu dan minggu
            if ($day != "Sun" && $day != "Sat") {
                //echo $i;
                $x    +=    $end - $i;
            }
            $end++;
            $i++;
        }
        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
            'date_end' => htmlspecialchars($this->input->post('date_end', true)),
            'status' => htmlspecialchars($this->input->post('status', true)),
            'kategori_cuti' => htmlspecialchars($this->input->post('jenis_cuti', true)),
            'persetujuan_dari' => htmlspecialchars($this->input->post('persetujuan', true)),
            'note' => htmlspecialchars($this->input->post('note', true)),
            'durasi' => $x + 1,
            'keterangan' => htmlspecialchars($this->input->post('keterangan', true))
        ];
        $this->db->where('id', $id);
        $this->db->update('cuti', $data);
    }
    public function tambah_cuti($post)
    {
        $awal =  htmlspecialchars($this->input->post('tanggal', true));
        $akhir = htmlspecialchars($this->input->post('date_end', true));

        $begin = new DateTime($awal);
        $end = new DateTime($akhir);

        $daterange     = new DatePeriod($begin, new DateInterval('P1D'), $end);
        //mendapatkan range antara dua tanggal dan di looping
        $i = 0;
        $x     =    0;
        $end     =    1;

        foreach ($daterange as $date) {
            $daterange     = $date->format("Y-m-d");
            $datetime     = DateTime::createFromFormat('Y-m-d', $daterange);

            //Convert tanggal untuk mendapatkan nama hari
            $day         = $datetime->format('D');

            //Check untuk menghitung yang bukan hari sabtu dan minggu
            if ($day != "Sun" && $day != "Sat") {
                //echo $i;
                $x    +=    $end - $i;
            }
            $end++;
            $i++;
        }
        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
            'email' => htmlspecialchars($this->input->post('email', true)),
            'nama_id' => htmlspecialchars($this->input->post('nama_id', true)),
            'kategori_cuti' => htmlspecialchars($this->input->post('jenis_cuti', true)),
            'date_end' => htmlspecialchars($this->input->post('date_end', true)),
            'keterangan' => htmlspecialchars($this->input->post('keterangan', true)),
            'foto' => htmlspecialchars($this->input->post('foto', true)),
            'divisi' => htmlspecialchars($this->input->post('divisi', true)),
            'date_created' => htmlspecialchars($this->input->post('date_created', true)),
            'durasi' => $x + 1,
            'status' => 1,
            'status1' => 1,
            'note' => ""
        ];
        $this->db->insert('cuti', $data);
    }
    public function kurangi_kuota($post)
    {
        $awal =  htmlspecialchars($this->input->post('tanggal', true));
        $akhir = htmlspecialchars($this->input->post('date_end', true));
        $id = htmlspecialchars($this->input->post('nama_id', true));

        $begin = new DateTime($awal);
        $end = new DateTime($akhir);

        $daterange     = new DatePeriod($begin, new DateInterval('P1D'), $end);
        //mendapatkan range antara dua tanggal dan di looping
        $i = 0;
        $x     =    0;
        $end     =    1;

        foreach ($daterange as $date) {
            $daterange     = $date->format("Y-m-d");
            $datetime     = DateTime::createFromFormat('Y-m-d', $daterange);

            //Convert tanggal untuk mendapatkan nama hari
            $day         = $datetime->format('D');

            //Check untuk menghitung yang bukan hari sabtu dan minggu
            if ($day != "Sun" && $day != "Sat") {
                //echo $i;
                $x    +=    $end - $i;
            }
            $end++;
            $i++;
            $durasi = $x + 1;
        }

        $this->db->select('SUM(kuota_cuti) AS total');
        $this->db->where('id', $id);
        $this->db->from('karyawan');
        $kuota = $this->db->get()->row()->total;

        $sum = $kuota - $durasi;

        $data = [
            'kuota_cuti' => $sum,
        ];
        $this->db->where('id', $id);
        $this->db->update('karyawan', $data);
    }
}
