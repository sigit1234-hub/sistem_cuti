<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_home extends CI_Model
{
    public function salam()
    {

        //ubah timezone menjadi jakarta
        date_default_timezone_set("Asia/Jakarta");

        //ambil jam dan menit
        $jam = date('H:i');

        //atur salam menggunakan IF
        if ($jam > '05:30' && $jam < '10:00') {
            $salam = 'pagi';
        } elseif ($jam >= '10:00' && $jam < '15:00') {
            $salam = 'siang';
        } elseif ($jam < '18:00') {
            $salam = 'sore';
        } else {
            $salam = 'malam';
        }

        //tampilkan pesan
        $tampil =  'Selamat ' . $salam;
        return $tampil;
    }
    public function tampil_data_peminjaman($id = null)
    {
        $this->db->from('permintaan');
        if ($id != null) {
            $this->db->where('id', $id);
        }
        $query = $this->db->order_by('id', 'DESC')->get();
        return $query;
    }
    public function hitung_peminjaman()
    {
        // jumlah seluruh
        $waktu = date("d-M-Y");
        // $query = "SELECT count(id) as peminjam FROM permintaan";
        // $result = $this->db->query($query);
        // return $result->row()->peminjam;

        $this->db->count_all_results('permintaan');  // Produces an integer, like 25
        $this->db->like('date_created', $waktu);
        $this->db->from('permintaan');
        $query = $this->db->count_all_results();
        return $query;
    }
    public function hitung_cuti()
    {
        $waktu = date("d-M-Y");
        $this->db->count_all_results('cuti');  // Produces an integer, like 25
        $this->db->like('date_created', $waktu);
        $this->db->from('cuti');
        $query = $this->db->count_all_results();

        return $query;
    }
    public function hitung_izin()
    {
        $waktu = date("d-M-Y");
        $this->db->count_all_results('izin');  // Produces an integer, like 25
        $this->db->like('date_created', $waktu);
        $this->db->from('izin');
        $query = $this->db->count_all_results();

        return $query;
    }
    public function hitung_spl()
    {
        $waktu = date("d-M-Y");
        $this->db->count_all_results('spl');  // Produces an integer, like 25
        $this->db->like('date_created', $waktu);
        $this->db->from('spl');
        $query = $this->db->count_all_results();

        return $query;
    }

    // hitung untuk user
    public function cuti_hari_ini()
    {
        $waktu = date("d-M-Y");
        $this->db->count_all_results('cuti');  // Produces an integer, like 25
        $this->db->like('tanggal', $waktu);
        $this->db->from('cuti');
        $query = $this->db->count_all_results();

        return $query;
    }
    public function izin_hari_ini()
    {
        $waktu = date("d-M-Y");
        $this->db->count_all_results('izin');  // Produces an integer, like 25
        $this->db->like('tanggal', $waktu);
        $this->db->from('izin');
        $query = $this->db->count_all_results();

        return $query;
    }
    public function spl_hari_ini()
    {
        $waktu = date("d-M-Y");
        $this->db->count_all_results('spl');  // Produces an integer, like 25
        $this->db->like('tanggal', $waktu);
        $this->db->from('spl');
        $query = $this->db->count_all_results();

        return $query;
    }
}
