<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User_m extends CI_Model
{
    public function tampil_data($id = null)
    {
        if ($id != null) {
            $sql = $this->db->order_by('id', 'Desc')->get_where('karyawan', ['id' => $id])->row_array();
            return $sql;
        } else {
            $sql = $this->db->order_by('id', 'Desc')->get_where('karyawan', ['username' => $this->session->userdata('username')])->row_array();
            return $sql;
        }
    }
    public function data_peminjaman($id = null)
    {
        if ($id != null) {
            $sql = $this->db->order_by('id', 'Desc')->get_where('permintaan', ['id_nama' => $id])->result_array();
            return $sql;
        } else {
            $sql = $this->db->order_by('id', 'Desc')->get_where('permintaan', ['id_nama' => $this->session->userdata('id')])->result_array();
            return $sql;
        }
    }

    public function data_cuti($id = null)
    {
        if ($id != null) {
            $sql = $this->db->order_by('id', 'Desc')->get_where('cuti', ['nama_id' => $id])->result_array();
            return $sql;
        } else {
            $sql = $this->db->order_by('id', 'Desc')->get_where('cuti', ['nama_id' => $this->session->userdata('id')])->result_array();
            return $sql;
        }
    }
    public function data_izin($id = null)
    {
        if ($id != null) {
            $sql = $this->db->order_by('id', 'Desc')->get_where('izin', ['nama_id' => $id])->result_array();
            return $sql;
        } else {
            $sql = $this->db->order_by('id', 'Desc')->get_where('izin', ['nama_id' => $this->session->userdata('id')])->result_array();
            return $sql;
        }
    }
    public function data_karyawan()
    {
        return $this->db->order_by('id', 'Desc')->get('karyawan')->result_array();
    }

    public function data_kasbon($id = null)
    {
        if ($id != null) {
            $sql = $this->db->order_by('id', 'Desc')->get_where('kasbon', ['nama_id' => $id])->result_array();
            return $sql;
        } else {
            return $this->db->order_by('id', 'DESC')->get_where('kasbon', ['nama_id' => $this->session->userdata('id')])->result_array();
        }
    }

    public function add_karyawan($post)
    {
        $upload_image = $_FILES['foto'];
        if ($upload_image) {
            $config['upload_path']          = './assets/img/profile/';
            $config['allowed_types']        = 'gif|jpg|png|jpeg|PNG';
            $config['max_size']             = 2048;
            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $new_image = $this->upload->data('file_name');
                $this->db->set('foto', $new_image);
            } else {
                echo $this->upload->display_errors();
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
                           Input data karyawan gagal!</div>');
                redirect('user/tambah_karyawan');
            }
            $data = [
                'sapaan' => htmlspecialchars($this->input->post('panggilan', true)),
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'username' => htmlspecialchars($this->input->post('username', true)),
                'password' => "Xx#" . htmlspecialchars($this->input->post('password', true)),
                'nrp' => "G" . htmlspecialchars($this->input->post('nrp', true)),
                'divisi' => htmlspecialchars($this->input->post('divisi', true)),
                'tanggal_gabung' => htmlspecialchars($this->input->post('tanggalgabung', true)),
                'tahun_gabung' => htmlspecialchars($this->input->post('tahungabung', true)),
                'ttl' => htmlspecialchars($this->input->post('tanggallahir', true)),
                'tempat' => htmlspecialchars($this->input->post('tempat', true)),
                'tahun_lahir' => htmlspecialchars($this->input->post('tahunlahir')),
                'alamat' => htmlspecialchars($this->input->post('alamat', true)),
                'jenjang' => htmlspecialchars($this->input->post('jenjang', true)),
                'pendidikan' => htmlspecialchars($this->input->post('sekolah', true)),
                'gol_darah' => htmlspecialchars($this->input->post('goldar', true)),
                'ktp' => htmlspecialchars($this->input->post('ktp', true)),
                'bpjs_kese' => htmlspecialchars($this->input->post('kese', true)),
                'bpjs_kete' => htmlspecialchars($this->input->post('kete', true)),
                'npwp' => htmlspecialchars($this->input->post('npwp', true)),
                'tlp' => htmlspecialchars($this->input->post('notlp', true)),
                'jabatan' => htmlspecialchars($this->input->post('jabatan', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'is_active' => 1,
                'role_id' => 5,
                'kuota_cuti' => 12

            ];

            $this->db->insert('karyawan', $data);
        }
    }

    public function edit_karyawan($post)
    {
        $id = $this->input->post('id', true);
        $data = [
            'sapaan' => htmlspecialchars($this->input->post('panggilan', true)),
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'username' => htmlspecialchars($this->input->post('username', true)),
            'password' => "Xx#" . htmlspecialchars($this->input->post('password', true)),
            'nrp' => "G" . htmlspecialchars($this->input->post('nrp', true)),
            'divisi' => htmlspecialchars($this->input->post('divisi', true)),
            'tanggal_gabung' => htmlspecialchars($this->input->post('tanggalgabung', true)),
            'tahun_gabung' => htmlspecialchars($this->input->post('tahungabung', true)),
            'ttl' => htmlspecialchars($this->input->post('tanggallahir', true)),
            'tempat' => htmlspecialchars($this->input->post('tempat', true)),
            'tahun_lahir' => htmlspecialchars($this->input->post('tahunlahir')),
            'alamat' => htmlspecialchars($this->input->post('alamat', true)),
            'jenjang' => htmlspecialchars($this->input->post('jenjang', true)),
            'pendidikan' => htmlspecialchars($this->input->post('sekolah', true)),
            'gol_darah' => htmlspecialchars($this->input->post('goldar', true)),
            'ktp' => htmlspecialchars($this->input->post('ktp', true)),
            'bpjs_kese' => htmlspecialchars($this->input->post('kese', true)),
            'bpjs_kete' => htmlspecialchars($this->input->post('kete', true)),
            'npwp' => htmlspecialchars($this->input->post('npwp', true)),
            'tlp' => htmlspecialchars($this->input->post('notlp', true)),
            'jabatan' => htmlspecialchars($this->input->post('jabatan', true)),
            'email' => htmlspecialchars($this->input->post('email', true)),
            'is_active' => htmlspecialchars_decode($this->input->post('aktif', true)),
            'role_id' => htmlspecialchars_decode($this->input->post('role_id', true))
        ];
        $upload_image3 = $_FILES['foto'];
        if ($upload_image3) {
            $config['upload_path']          = './assets/img/profile/';
            $config['allowed_types']        = 'gif|jpg|png|jpeg|PNG';
            $config['max_size']             = 2048;
            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $old_image = $this->input->post('fotoasli', true);
                if ($old_image != 'default.jpg') {
                    unlink(FCPATH . 'assets/img/profile/' . $old_image);
                }
                $new_image = $this->upload->data('file_name');
                $this->db->set('foto', $new_image);
            }
            $where = array('id' => $id);
            $this->User_m->update_kar($where, $data, 'karyawan');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Update Data berhasil!</div>');
            redirect('User/data_karyawan');
        }
    }

    public function lihat_karyawan($id = null)
    {
        $this->db->from('karyawan');
        if ($id != null) {
            $this->db->where('id', $id);
        }
        $query = $this->db->order_by('id', 'DESC')->get();
        return $query;
    }
    public function cuti_person($id = null)
    {
        $this->db->from('cuti');
        if ($id != null) {
            $this->db->where('id', $id);
        }
        $query = $this->db->order_by('id', 'DESC')->get()->result_array();
        return $query;
    }
    public function edit_kar($where, $table)
    {
        return $this->db->get_where($table, $where);
    }
    public function update_kar($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    public function del($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('karyawan');
    }

    public function ambilgambar($id)
    {
        $this->db->from('karyawan');
        $this->db->where('id', $id);
        $result = $this->db->get('');
        if ($result->num_rows() > 0) {
            return $result->row();
        }
    }
    public function _kuota($id)
    {
        $this->db->select('SUM(kuota_cuti) AS total');
        $this->db->where('id', $id);
        $this->db->from('karyawan');
        $sum2 = $this->db->get()->row()->total;
        return $sum2;
    }

    public function get_sisa_cuti($id = null)
    {
        if ($id != null) {
            $this->db->select('SUM(kuota_cuti) AS total');
            $this->db->where('id', $id);
            $this->db->from('karyawan');
            $kuota = $this->db->get()->row()->total;
            return $kuota;
        } else {
            $sql = $this->session->userdata('id');
            $this->db->select('SUM(kuota_cuti) AS total');
            $this->db->where('id', $sql);
            $this->db->from('karyawan');
            $kuota = $this->db->get()->row()->total;
            return $kuota;
        }
    }

    public function get_jumlah_izin($id = null)
    {
        if ($id != null) {
            $this->db->select('SUM(durasi) AS total');
            $this->db->where('nama_id', $id);
            return $this->db->get('izin')->row()->total;
        }
        $id = $this->session->userdata('id');
        $this->db->select('SUM(durasi) AS total');
        $this->db->where('nama_id', $id);
        return $this->db->get('izin')->row()->total;
    }
    public function ambil_karyawan()
    {
        return $this->db->get('karyawan')->result_array();
    }

    public function _finance()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 1])->result_array();
    }
    public function _logistic()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 2])->result_array();
    }
    public function _service()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 13])->result_array();
    }
    public function _warehouse()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 14])->result_array();
    }
    public function _ga()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 15])->result_array();
    }
    public function _it()
    {
        $query = "SELECT * FROM karyawan WHERE divisi IN ('17', '23');";
        return $this->db->query($query)->result_array();
    }
    public function _manufaktur()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 18])->result_array();
    }
    public function _marketing()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 22])->result_array();
    }
    public function lain()
    {
        return  $this->db->get_where('karyawan', ['divisi' => 22])->result_array();
    }
    public function get_ultah()
    {
        $date = date('j-M');
        return  $this->db->get_where('karyawan', ['ttl' => $date])->result_array();
    }
    public function sisa_kasbon($id = null)
    {
        if ($id != null) {
            $this->db->select('SUM(kasbon) AS total');
            $this->db->where('id', $id);
            $this->db->where('bayar', 'Berlangsung');
            $this->db->from('kasbon');
            return $this->db->get()->row()->total;
        } else {
            $sql = $this->session->userdata('id');
            $this->db->select('SUM(kasbon) AS total');
            $this->db->where('nama_id', $sql);
            $this->db->where('bayar', "Berlangsung");
            $this->db->from('kasbon');
            return $this->db->get()->row()->total;
        }
    }
    public function update_kuota()
    {
        $date = date('j-M');
        $this->db->where('tanggal_gabung', $date);
        $this->db->where('kuota_cuti !=', '12');
        return $this->db->get('karyawan')->result_array();
    }
    public function update_cuti()
    {
        $id = $this->input->post('id', true);
        $this->db->where('id', $id);
        $this->db->update('karyawan', ['kuota_cuti' => 12]);
    }
}
