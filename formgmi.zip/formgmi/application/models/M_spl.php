<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_spl extends CI_Model
{
    public function tampil_data($id = null)
    {
        $this->db->from('spl');
        if ($id != null) {
            $this->db->where('id', $id);
        }
        $query = $this->db->order_by('id', 'DESC')->get()->result_array();
        return $query;
    }
    public function data_email_head($id)
    {
        $this->db->where('id', $id);
        $jab =  $this->db->get('devisi');
        foreach ($jab->result_array() as $row) {
            // echo  "<option value='" . $row['id'] . "'>" . $row['nama'] . "</option>";
            echo  "<option >" . $row['email_head'] . "</option>";
        }
    }
    public function tambah_spl()
    {
        $table = "spl";
        $field = "kode_spl";

        $lastcode = $this->kodespl_model->getMax($table, $field);

        //mengambil 4 nomor urut dari belakang
        $noUrut = (int)substr($lastcode, -4, 4); //substr =sub string mengambil string yang ada dalam db (int) agar berubah jadi int,-4 mengambil nomor urut dari belakang sebanyak 4
        $noUrut++;

        $today = date('y');

        //ubah kembali jadi string
        $str = "SPL-GMI";
        $newCode = $str . "-" . $today . "-" . sprintf('%04s', $noUrut); //%04s = merubah dari 1 digit jadi 4 ext 1 = 0001


        if (isset($_POST["anggota"])) {
            $framework = '';
            foreach ($_POST["anggota"] as $row) {
                $framework .= $row . ', ';
            }
            $framework = substr($framework, 0, -2);
        }
        $data = [
            'kode_spl' => $newCode,
            'date_created' => htmlspecialchars($this->input->post('date_created', true)),
            'status' => 1,
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'email' => htmlspecialchars($this->input->post('email', true)),
            'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
            'date_end' => htmlspecialchars($this->input->post('date_end', true)),
            'divisi' => htmlspecialchars($this->input->post('divisi', true)),
            'pekerjaan' => htmlspecialchars($this->input->post('deskripsi', true)),
            'anggota' => $framework,
            'mengetahui' => '',
            'emailhead' => htmlspecialchars($this->input->post('emailhead', true)),
            'note' => '',
            'jam' => htmlspecialchars($this->input->post('jam', true)),
            'kembali' => htmlspecialchars($this->input->post('kembali', true)),
            'foto' => htmlspecialchars($this->input->post('foto', true)),
        ];

        $this->db->insert('spl', $data);
    }
    public function del($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('spl');
    }
    public function edit($post)
    {
        $id = $this->input->post('id', true);

        $data = [
            'nama' => htmlspecialchars($this->input->post('nama', true)),
            'tanggal' => htmlspecialchars($this->input->post('tanggal', true)),
            'date_end' => htmlspecialchars($this->input->post('date_end', true)),
            'anggota' => htmlspecialchars($this->input->post('anggota', true)),
            'status' => htmlspecialchars($this->input->post('status', true)),
            'jam' => htmlspecialchars($this->input->post('jam', true)),
            'kembali' => htmlspecialchars($this->input->post('kembali', true)),
            'pekerjaan' => htmlspecialchars($this->input->post('deskripsi', true)),
            'note' => htmlspecialchars($this->input->post('catatan', true)),
        ];

        $this->db->update('spl', $data, ['id' => $id]);
    }
    public function divisi_data()
    {
        return $this->db->order_by('nama_divisi', 'ASC')->get('devisi')->result_array();
    }
}
